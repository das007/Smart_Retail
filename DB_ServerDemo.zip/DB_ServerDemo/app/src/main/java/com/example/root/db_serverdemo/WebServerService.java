package com.example.root.db_serverdemo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class WebServerService extends Service {
    public WebServerService()
    {

    }

    @Override
    public void onCreate()
    {
        super.onCreate();

        SimpleWebServer ws=new SimpleWebServer(8080,this.getAssets(),this);
        ws.start();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
