package com.example.root.db_serverdemo;

import android.content.Context;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Created by Ara on 10/16/15.
 */
public class ClientConnection extends Thread {
    private final Context context;
    private Socket socket;
    JSON json;

    public ClientConnection(Socket socket, Context context){
        this.socket=socket;
        this.context = context;
        json = new JSON(context);

    }

    public void run(){
        try {
            HTTPRequest request = HTTPProcessor.readHTTPGetRequest(socket.getInputStream());
            DataOutputStream output = new DataOutputStream((socket.getOutputStream()));
            Log.i("hello","made my request and such");
            if(request.getResource()==null)
            {
                System.out.println("######$$$$$$$$$RESOURCE IS NULL...");
            }
            else if(request.getResource().equals("/")&&request.isGet()){
                Log.i("hello","At /");
                output.writeUTF(setUpHTTPMessage(context.getString(R.string.default_html_page), "text/html"));
                Log.i("hello","Just wrote!");

            }else if(request.getResource().equals("/status")&&request.isGet()){
                Log.i("hello","At stsus");

                JSONObject jsonObject = json.createJSON();
                output.writeUTF(setUpHTTPMessage(jsonObject.toString(), "application/json"));

            }else if(request.getResource().equals("/status/pretty")&&request.isGet()) {
                Log.i("hello","At purty");

                JSONObject jsonObject = json.createJSON();

                try {
                    output.writeUTF(setUpHTTPMessage(jsonObject.toString(2), "application/json"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                output.writeUTF(setUpHTTPMessage(jsonObject.toString(), "application/json"));
            }else if(request.getResource().equals("/led")&&request.isGet()){
                String timestring = request.getQueryString("times");
                int times = 5;
                if(timestring!=null){
                    times = Integer.parseInt(timestring);
                }


//                boolean red=false,yellow=false,green=false;
//                if(request.getQueryString("color").equals("all")){
//                    red=yellow=green=true;
//                }
//                else if(request.getQueryString("color").equals("red")){
//                    red=true;
//                }
//                else if(request.getQueryString("color").equals("yellow")){
//                    yellow=true;
//                }
//                else if(request.getQueryString("color").equals("green")){
//                    green=true;
//                }
//                else{
//                    times=0;
//                }
                if(LEDBlinker.blink(times,true)){
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"OK\"}","application/json"));
                }else{
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Led is currently in use!\"}","application/json"));

                }
            }
            else if(request.getResource().equals("/ac")&&request.isGet())
            {
                String set=request.getQueryString("set");
                if(set==null)
                {
                    int ac_status=LEDBlinker.getAC_status();
                    if(ac_status==1)
                    {
                        output.writeUTF(setUpHTTPMessage("{\"status\":\"AC in ON\"}", "application/json"));
                    }
                    else
                    {
                        output.writeUTF(setUpHTTPMessage("{\"status\":\"AC in OFF\"}", "application/json"));
                    }
                }
                else
                {
                    int set_Status = 0;
                    if (set.equalsIgnoreCase("on")) {
                        set_Status = 1;
                    } else if (set.equalsIgnoreCase("off")) {
                        set_Status = 0;
                    }

                    if (LEDBlinker.setAC(set_Status)) {
                        output.writeUTF(setUpHTTPMessage("{\"status\":\"OK\"}", "application/json"));
                    } else {
                        output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Someone else is handling the AC!\"}", "application/json"));
                    }
                }
            }
            else if(request.getResource().equals("/lifi/1")&&request.isGet())
            {
                System.out.println("############## LIFI 1 on");
                int result=LEDBlinker.LIFI1(1);

                if (result==1) {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"LIFI 1 ON\"}", "application/json"));
                } else {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Someone else is handling the LIFI 1!\"}", "application/json"));
                }
            }
            else if(request.getResource().equals("/lifi/0")&&request.isGet())
            {
                System.out.println("############## LIFI 0 on");
                int result=LEDBlinker.LIFI1(0);

                if (result==0) {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"LIFI 0 ON\"}", "application/json"));
                } else {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Someone else is handling the LIFI 0!\"}", "application/json"));
                }
            }
            else if(request.getResource().equals("/lifi1/1")&&request.isGet())
            {
                System.out.println("############## LIFI1 1 on");
                int result=LEDBlinker.LIFI2(1);

                if (result==1) {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"LIFI1 1 ON\"}", "application/json"));
                } else {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Someone else is handling the LIFI1 1!\"}", "application/json"));
                }
            }
            else if(request.getResource().equals("/lifi1/0")&&request.isGet())
            {
                System.out.println("############## LIFI1 0 on");
                int result=LEDBlinker.LIFI2(0);

                if (result==0) {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"LIFI1 0 ON\"}", "application/json"));
                } else {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Someone else is handling the LIFI1 0!\"}", "application/json"));
                }
            }
            else if(request.getResource().equals("/lifi1")&&request.isGet()){
                String set_val = request.getQueryString("set");
//                if(timestring!=null){
//                    times = Integer.parseInt(timestring);
//                }
                if(set_val.equalsIgnoreCase("on"))
                {
//                    LEDBlinker.LIFI1_ON=true;
                    LEDBlinker.LIFI_MODE=0;
                    LEDBlinker.LIFI2(0);
//                    LEDBlinker.LIFI1_ON=true;
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"LIFI1 turned on\"}","application/json"));
                }
                else if(set_val.equalsIgnoreCase("off"))
                {
                    LEDBlinker.LIFI1_ON=false;
                    GpioProcessor gpioProc=new GpioProcessor();
                    GpioProcessor.Gpio lifi_Gpio = gpioProc.getPin25();
                    lifi_Gpio.low();
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"LIFI1 turned off\"}","application/json"));
                }
                else{
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Wrong Parameters!\"}","application/json"));

                }
            }
            else if(request.getResource().equals("/security_on")&&request.isGet())
            {
                int result=LEDBlinker.setSecurity(1);

                if (result==1) {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Security set on\"}", "application/json"));
                }
                else {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Someone else is handling SEcurity!\"}", "application/json"));
                }
            }
            else if(request.getResource().equals("/security_off")&&request.isGet())
            {
                int result=LEDBlinker.setSecurity(0);

                if (result==0) {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Security set off\"}", "application/json"));
                }
                else {
                    output.writeUTF(setUpHTTPMessage("{\"status\":\"Error: Someone else is handling SEcurity!\"}", "application/json"));
                }
            }
            else
            {
                Log.i("hello","At error inside if");

                String content = context.getString(R.string.error_html_page);
                SimpleDateFormat dateFormat =
                        new SimpleDateFormat(context.getString(R.string.date_format),
                                Locale.US);
                dateFormat.setTimeZone(TimeZone.getTimeZone(context.getString(
                        R.string.time_zone)));

                output.writeUTF("HTTP/1.1 404 Not Found\r\n" +
                        "Date: " + dateFormat.format(new Date()).replace("+00:00", "") +
                        "\r\n" +
                        "Content-Type: text/html\r\n" +
                        "Content-Length: " + content.length() + "\r\n" + "\r\n" +
                        content);
            }
//            Log.i("hello","At error outside if");

            socket.close();
        } catch (IOException e) {
            Log.i("hello","At error caught");

            e.printStackTrace();
        }
    }



    /**
     * Name:        setUpHTTPMessage
     * Description: Formats the message into an HTTP request that is to be sent
     *              to the server.
     *
     * @param content       String containing the content of the message
     * @param content_type  String containing the "Content-Type"
     * @return              String containing the formatted HTTP request
     *                      message
     */
    public String setUpHTTPMessage(String content, String content_type){
        SimpleDateFormat dateFormat =
                new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",
                        Locale.US);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

        return "HTTP/1.1 200 OK\r\n"+
                "Date: " + dateFormat.format(new Date()).replace("+00:00", "") +
                "\r\n" +
                "Content-Type: " + content_type + "\r\n" +
                "Content-Length: " + content.length() + "\r\n"+ "\r\n" +
                content;
    }
}
