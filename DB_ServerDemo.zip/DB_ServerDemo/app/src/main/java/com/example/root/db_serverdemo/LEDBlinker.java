package com.example.root.db_serverdemo;

/**
 * Created by Ara on 10/20/15.
 */
public class LEDBlinker{
    public static int LIFI_MODE=0;
    public static boolean LIFI1_ON=false;
    private static boolean lock = false;
    private static boolean lockAC = false;
    private static int SECURITY_MODE=0;
    public static boolean securityOn=false;

    public static boolean blink(final int times, final boolean red){
        if(!lock) {
            setLock(true);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    GpioProcessor gpioProcessor = new GpioProcessor();
                    GpioProcessor.Gpio redGpio = gpioProcessor.getPin29();
//                    GpioProcessor.Gpio yellowGpio = gpioProcessor.getPin26();
//                    GpioProcessor.Gpio greenGpio = gpioProcessor.getPin24();
                    redGpio.out();
//                    yellowGpio.out();
//                    greenGpio.out();
                    for (int i = 0; i < times; i++) {
                        if(red){
                           redGpio.high();
                        }
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if(red){
                            redGpio.low();
                        }
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    setLock(false);


                }
            }).start();
            return true;
        }

        return false;
    }

    public static boolean setAC(final int set)
    {
        if(!lockAC) {
            setAC_Lock(true);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    GpioProcessor gpioProcessor = new GpioProcessor();
                    GpioProcessor.Gpio AC_Gpio = gpioProcessor.getPin23();
                    if(set==1)
                    {
                        AC_Gpio.high();
                    }
                    else if(set==0)
                    {
                        AC_Gpio.low();
                    }
//
                    setAC_Lock(false);


                }
            }).start();
            return true;
        }

        return false;
    }

    public static int getAC_status()
    {
        GpioProcessor gpioProcessor = new GpioProcessor();
        GpioProcessor.Gpio AC_Gpio = gpioProcessor.getPin23();
        return AC_Gpio.getValue();
    }

    public static int LIFI1(int lifi_mode)
    {
        GpioProcessor gpioProcessor = new GpioProcessor();
        GpioProcessor.Gpio lifi_Gpio = gpioProcessor.getPin32();
        lifi_Gpio.out();

        if(lifi_mode==0)
        {
            lifi_Gpio.low();
            System.out.println("LIFI 0==="+lifi_Gpio.getValue());
            return 0;
        }
        else
        {
            lifi_Gpio.high();
            System.out.println("LIFI 1==="+lifi_Gpio.getValue());
            return 1;
        }
    }

    public static int LIFI2(int lifi_mode)
    {
        if(!LIFI1_ON)
        {
            LIFI_Blinker lb=new LIFI_Blinker();
            Thread t=new Thread(lb);
            t.start();
            LIFI1_ON=true;
        }
        if(lifi_mode==0)
        {
            LIFI_MODE=0;
            return 0;
        }
        else
        {
            LIFI_MODE=1;
            return 1;
        }
    }

    public static int setSecurity(int mode)
    {
        Security_Thread sth=new Security_Thread();

        if(SECURITY_MODE==mode)
        {
            System.out.println("Security mode is same...");
            return mode;
        }
        else
        {
            SECURITY_MODE=mode;
            if (mode == 1)
            {
                securityOn=true;
                Thread t = new Thread(sth);
                t.start();
                return 1;
            }
            else
            {
                securityOn=false;
                System.out.println("Security is set off");
            }
        }
        return 0;
    }

//    public static boolean blinkPattern(String pattern)
//    {
//
//    }

    private static void setLock(boolean status){
        lock= status;
    }

    private static void setAC_Lock(boolean status){
        lockAC= status;
    }

    private static void blinkLED(GpioProcessor.Gpio led){
        led.high();

        led.low();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
