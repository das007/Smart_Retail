package com.example.root.db_serverdemo;

/**
 * Created by root on 29/5/17.
 */

public class Security_Thread implements Runnable
{
    public void run()
    {
        GpioProcessor gpioProcessor=new GpioProcessor();
        GpioProcessor.Gpio tilt_Gpio = gpioProcessor.getPin27();
        tilt_Gpio.in();

        GpioProcessor.Gpio led_Gpio = gpioProcessor.getPin29();
        led_Gpio.out();
        led_Gpio.low();

        int previous=tilt_Gpio.getValue();
        while(LEDBlinker.securityOn)
        {
            System.out.println("Security Thread running..."+LEDBlinker.securityOn);
            int current=tilt_Gpio.getValue();
            if(previous!=current)
            {
                led_Gpio.high();
            }
            previous=current;
        }

        led_Gpio.low();
        System.out.println("Security Thread Ended...");
    }


}
