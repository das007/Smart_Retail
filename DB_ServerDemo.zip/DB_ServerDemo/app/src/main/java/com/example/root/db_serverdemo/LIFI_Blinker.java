package com.example.root.db_serverdemo;

/**
 * Created by root on 29/5/17.
 */

public class LIFI_Blinker implements Runnable
{
    public void run()
    {

        GpioProcessor gpioProcessor=new GpioProcessor();
//        GpioProcessor.Gpio tilt_Gpio = gpioProcessor.getPin25();
//        tilt_Gpio.in();

        GpioProcessor.Gpio led_Gpio = gpioProcessor.getPin25();
        led_Gpio.out();
        led_Gpio.low();

//        int previous=tilt_Gpio.getValue();
        while(LEDBlinker.LIFI1_ON)
        {
            if(LEDBlinker.LIFI_MODE==1) {
                led_Gpio.high();
                try {
                    Thread.sleep(250);
                } catch (Exception e) {
                }

                led_Gpio.low();
                try {
                    Thread.sleep(251);
                } catch (Exception e) {
                }
            }
            else
            {
                led_Gpio.high();
                try {
                    Thread.sleep(500);
                } catch (Exception e) {
                }

                led_Gpio.low();
                try {
                    Thread.sleep(502);
                } catch (Exception e) {
                }
            }
        }

        led_Gpio.low();
        System.out.println("Security Thread Ended...");
    }
}
