package com.example.root.db_serverdemo;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    SimpleWebServer ws;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Intent intent=new Intent(this,WebServerService.class);
//        startService(intent);

        System.out.println("Activity created...");
        Log.v("DB","ACT started...");
        ws=new SimpleWebServer(7777,this.getAssets(),this);
        ws.start();
        System.out.println("Server started...");
        Log.v("DB","Server started...");

//        finish();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ws.stop();
    }
}
