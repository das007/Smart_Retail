package com.example.root.fire_theft_alarm;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;

/**
 * Created by root on 28/5/17.
 */

public class Alarm_Thread implements Runnable
{
    int FIRE_ALARM=0;
    int STOCK_ALARM=0;
    int FIRE_ON=0;
    int STOCK_LOW=0;

    Context context=null;

    boolean stop_thread=false;

    public Alarm_Thread(Context context)
    {
        this.context=context;
    }

    public void run()
    {
//        VideoThread videoFireThread=new VideoThread("/storage/emulated/0/DCIM/Camera/wonderla.mp4");
//        VideoThread videoStockThread=new VideoThread("/storage/emulated/0/DCIM/Camera/wonderla2.mp4");

        try {
            GpioProcessor gpioProcessor = new GpioProcessor();
            GpioProcessor.Gpio gpio_temperature = gpioProcessor.getPin26();
            GpioProcessor.Gpio gpio_stock_status = gpioProcessor.getPin24();
            GpioProcessor.Gpio gpio_stock_status_clear = gpioProcessor.getPin34();
            gpio_temperature.in();
            gpio_stock_status.in();
            gpio_stock_status_clear.out();
            gpio_stock_status_clear.high();
            Thread.sleep(1000);
            gpio_stock_status_clear.low();


            boolean link_open=false;

            while (!stop_thread) {
                System.out.println(FIRE_ALARM+" "+FIRE_ON);
                System.out.println("###########FIRE Detecting...");
                int temperature_value = gpio_temperature.getValue();
                int stock_status = gpio_stock_status.getValue();


                if (temperature_value == GpioProcessor.Gpio.HIGH && FIRE_ALARM == 0) {

                    System.out.println("############### FIRE ALARM set ON");

                    gpioProcessor.getPin29().high();
                    FIRE_ALARM = 1;

                    new java.util.Timer().schedule(
                            new java.util.TimerTask() {
                                @Override
                                public void run() {
                                    FIRE_ON=1;
                                }
                            },
                            10000
                    );
                }
//                if (stock_status == GpioProcessor.Gpio.HIGH && STOCK_ALARM == 0)
//                {
//
//                    System.out.println("############### STOCK Empty set ON");
//                    gpio_stock_status_clear.high();
//                    gpioProcessor.getPin29().high();
//                    STOCK_ALARM= 1;
//
//                    Thread t=new Thread(new Runnable() {
//                        @Override
//                        public void run() {
//                            try {
//                                Thread.sleep(10000);
//                                STOCK_ALARM=0;
//                                STOCK_LOW=1;
//                            }
//                            catch(Exception e)
//                            {
//                                e.printStackTrace();
//                            }
//                        }
//                    });
//                    t.start();
//
//                }
                if (temperature_value == GpioProcessor.Gpio.LOW && FIRE_ALARM == 1 && FIRE_ON==1)
                {
                    gpioProcessor.getPin29().low();
                    FIRE_ALARM = 0;
                    FIRE_ON=0;

                    System.out.println("############### FIRE ALARM set OFF");
                }
//                if (STOCK_LOW==1)
//                {
//                    System.out.println("############### STOCK NOT Empty");
//                    gpioProcessor.getPin29().low();
//                    gpio_stock_status_clear.low();
//                    STOCK_LOW=0;
//
//                }

                if(FIRE_ALARM==1 && link_open==false)
                {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.co.in/search?channel=fs&q=fire+image&ie=utf-8&oe=utf-8&gfe_rd=cr&ei=mZIrWYb1GKXv8wei-bDYCw#safe=active&channel=fs&q=fire"));
                    context.startActivity(browserIntent);
                    link_open=true;
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Excep in fire="+e);
            e.printStackTrace();
        }
    }

    public void stopThread()
    {
        stop_thread=true;
    }

    public void blinkLED(GpioProcessor.Gpio pin)
    {

    }
}
