package com.example.root.fire_theft_alarm;

import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    final int PERMISSION_WRITE_EXTERNAL_PUB=5;

    Thread alarmThread=null;
    Alarm_Thread ath=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        try {
//            MediaPlayer mp = new MediaPlayer();
//            mp.setDataSource("/storage/emulated/0/DCIM/Camera/wonderla.mp4");
//            mp.prepare();
//            mp.start();
//        }
//        catch(Exception e)
//        {
//            System.out.println(e);
//            e.printStackTrace();
//        }

//        if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED)
//        {
//            ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},PERMISSION_WRITE_EXTERNAL_PUB);
////            startThread();
//        }
//        else
//        {
//            startThread();
//        }


        ath=new Alarm_Thread(this);
        alarmThread=new Thread(ath);
        alarmThread.start();
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        ath.stopThread();
    }

//    public void startThread()
//    {
//        Thread alarmThread=new Thread(new Alarm_Thread());
//        alarmThread.start();
//    }

//    public void onRequestPermissionsResult(int requestCode,
//                                       String permissions[], int[] grantResults) {
//    switch (requestCode) {
//        case PERMISSION_WRITE_EXTERNAL_PUB:
//        {
//            if (grantResults.length > 0
//                    && grantResults[0] == PackageManager.PERMISSION_GRANTED)
//            {
////                startThread();
//                // permission was granted, yay! Do the
//                // contacts-related task you need to do.
//            }
//            else
//            {
//                Toast.makeText(this,"Permission Denied.",Toast.LENGTH_SHORT).show();
//            }
//            return;
//        }
//    }
//}



//    public void saveToExtPublic(View view)
//    {
//        if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED)
//        {
//            ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},PERMISSION_WRITE_EXTERNAL_PUB);
//        }
//    }
}
