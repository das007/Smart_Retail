package com.example.root.fire_theft_alarm;

import android.media.MediaPlayer;

/**
 * Created by root on 28/5/17.
 */

public class VideoThread implements Runnable
{
    String videoPath="";
    boolean stopThread=false;

    public VideoThread(String path)
    {
        videoPath=path;
    }

    public void run()
    {
        try
        {
//            while(!stopThread)
//            {
                MediaPlayer mp = new MediaPlayer();
                mp.setDataSource(videoPath);
                mp.prepare();
                mp.start();
//            }
        }
        catch(Exception e)
        {
            System.out.println("Media error="+e);
            e.printStackTrace();
        }
    }

    public void setStopThread()
    {
        stopThread=true;
    }
}
